<?php
// Include the database connection
include 'components/connect.php';
 
// Check if user is logged in
if (isset($_COOKIE['user_id'])) {
    $user_id = $_COOKIE['user_id'];
} else {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit;
}
 
// Get the property ID and price from the query parameters
$property_id = isset($_GET['property_id']) ? $_GET['property_id'] : null;
$price = isset($_GET['price']) ? $_GET['price'] : null;
 
if (!$property_id || !$price) {
    // Handle missing property_id or price
    echo "Error: Missing property ID or price.";
    exit;
}
 
// Simulated payment process
// This is where you would typically handle payment processing
// using a payment gateway API, such as Stripe, PayPal, etc.
 
// For demonstration purposes, let's assume the payment is successful
 
// Log payment details in the database
$insert_payment = $conn->prepare("INSERT INTO payments (user_id, property_id, amount) VALUES (?, ?, ?)");
$insert_payment->execute([$user_id, $property_id, $price]);
 
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payment</title>
<style>
        /* CSS styles */
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }
 
        .payment-form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
 
        .payment-options {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
 
        .payment-options label {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-right: 10px; /* Adjust the margin between icons */
            cursor: pointer;
        }
 
        .payment-options label img {
            width: 50px; /* Adjust the size as needed */
            height: auto;
            margin-bottom: 5px;
        }
 
        .payment-options label span {
            font-size: 14px;
        }
 
        button[type="submit"] {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
 
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
</style>
</head>
<body>
 
<div class="container">
<h1>Payment Details</h1>
<p>Please select a payment method to proceed with the payment for the property.</p>
<form action="process_payment.php" method="post" class="payment-form">
<input type="hidden" name="property_id" value="<?= $property_id ?>">
<input type="hidden" name="price" value="<?= $price ?>">
<div class="payment-options">
<label for="debit">
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/MasterCard_Logo.svg/1200px-MasterCard_Logo.svg.png" alt="Debit Card">
<input type="radio" id="debit" name="payment_method" value="debit" required>
<span>Debit Card</span>
</label>
<label for="credit">
<img src="https://cdn.worldvectorlogo.com/logos/visa-4.svg" alt="Credit Card">
<input type="radio" id="credit" name="payment_method" value="credit" required>
<span>Credit Card</span>
</label>
<label for="apple_pay">
<img src="apple.jpg" alt="Apple Pay">
<input type="radio" id="apple_pay" name="payment_method" value="apple_pay" required>
<span>Apple Pay</span>
</label>
<label for="paypal">
<img src="https://cdn.worldvectorlogo.com/logos/paypal-2.svg" alt="PayPal">
<input type="radio" id="paypal" name="payment_method" value="paypal" required>
<span>PayPal</span>
</label>
</div>
<button type="submit">Confirm Payment</button>
</form>
</div>
 
</body>
</html>