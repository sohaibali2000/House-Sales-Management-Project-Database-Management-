<?php
include 'components/connect.php';

if (isset($_COOKIE['user_id'])) {
    $user_id = $_COOKIE['user_id'];
} else {
    $user_id = '';
    header('location:login.php');
}

// Get property ID from URL parameter
$property_id = isset($_GET['property_id']) ? filter_var($_GET['property_id'], FILTER_SANITIZE_NUMBER_INT) : 0;

// Check if property ID is valid
if ($property_id <= 0) {
    die('Invalid property ID.');
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get user input
    $user_name = isset($_POST['name']) ? filter_var($_POST['name'], FILTER_SANITIZE_STRING) : '';
    $user_email = isset($_POST['email']) ? filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) : '';
    $user_phone = isset($_POST['phone']) ? filter_var($_POST['phone'], FILTER_SANITIZE_STRING) : '';
    $appointment_date = isset($_POST['date']) ? filter_var($_POST['date'], FILTER_SANITIZE_STRING) : '';
    $appointment_time = isset($_POST['time']) ? filter_var($_POST['time'], FILTER_SANITIZE_STRING) : '';

    // Validate inputs
    if ($user_name && $user_email && $user_phone && $appointment_date && $appointment_time) {
        // Prepare and execute the query to insert the appointment
        $insert_appointment = $conn->prepare("INSERT INTO appointments (property_id, user_name, user_email, user_phone, appointment_date, appointment_time) VALUES (?, ?, ?, ?, ?, ?)");

        if ($insert_appointment->execute([$property_id, $user_name, $user_email, $user_phone, $appointment_date, $appointment_time])) {
            $message = 'Appointment scheduled successfully!';
        } else {
            $message = 'Failed to schedule appointment. Please try again later.';
        }
    } else {
        $message = 'All fields are required.';
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule Appointment</title>

    <!-- Font Awesome CDN link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <!-- Custom CSS file link -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Add CSS styling for form layout -->
    <style>
        /* Form container */
        .appointment-form {
            max-width: 500px; /* Limit form width for readability */
            padding: 20px; /* Add padding to the form */
            border: 1px solid #ccc; /* Add a border */
            border-radius: 10px; /* Add rounded corners */
            margin: 20px auto; /* Center the form on the page */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Add a slight shadow */
        }

        /* Form input boxes */
        .input-box {
            margin-bottom: 15px; /* Space out form inputs */
        }

        /* Form input elements */
        .input-box input {
            width: 100%; /* Make input full width */
            padding: 10px; /* Add padding */
            border-radius: 5px; /* Add rounded corners */
            border: 1px solid #ccc; /* Add a border */
        }

        /* Form labels */
        label {
            display: block; /* Make labels block elements */
            margin-bottom: 5px; /* Add space between labels and inputs */
            font-weight: bold; /* Make labels bold */
        }

        /* Form buttons */
        .btn {
            padding: 10px 15px; /* Add padding to buttons */
            background-color: #007bff; /* Button color */
            color: white; /* Button text color */
            border: none; /* Remove border */
            border-radius: 5px; /* Add rounded corners */
            cursor: pointer; /* Pointer cursor */
            display: inline-block; /* Button as an inline block */
            margin-top: 15px; /* Add top margin for separation */
        }

        /* Button hover state */
        .btn:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        /* Message container */
        .message {
            background-color: #d4edda; /* Success message background */
            color: #155724; /* Success message text color */
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px; /* Rounded corners */
        }
    </style>
</head>
<body>

<?php include 'components/user_header.php'; ?>

<section class="appointment">
    <h1 class="heading">Schedule an Appointment</h1>

    <?php if ($message): ?>
        <div class="message"><?= $message; ?></div>
    <?php endif; ?>

    <form method="POST" class="appointment-form">
        <input type="hidden" name="property_id" value="<?= $property_id; ?>">

        <div class="input-box">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" placeholder="Enter your name" required>
        </div>

        <div class="input-box">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>
        </div>

        <div class="input-box">
            <label for="phone">Phone:</label>
            <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" required>
        </div>

        <div class="input-box">
            <label for="date">Appointment Date:</label>
            <input type="date" id="date" name="date" required>
        </div>

        <div class="input-box">
            <label for="time">Appointment Time:</label>
            <input type="time" id="time" name="time" required>
        </div>

        <button type="submit" class="btn">Schedule Appointment</button>
    </form>
</section>

<?php include 'components/footer.php'; ?>

<!-- Custom JS file link -->
<script src="js/script.js"></script>

</body>
</html>
