<?php  
 
include 'components/connect.php';
 
if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}
 
include 'components/save_send.php';
 
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home</title>
 
   <!-- font awesome cdn link  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
 
   <!-- custom css file link  -->
<link rel="stylesheet" href="css/style.css">
 
   <script>
   document.addEventListener("DOMContentLoaded", function() {
       const offerTypeElement = document.getElementById('h_offer');
       const minBudgetElement = document.getElementById('h_min');
       const maxBudgetElement = document.getElementById('h_max');
 
       function updateBudgetDropdowns() {
           const offerType = offerTypeElement.value;
           const budgets = {
               'sale': [
                   {min: '400k', max: '800k'},
                   {min: '800k', max: '1.2M'},
                   {min: '1.2M', max: '1.5M'},
                   {min: '1.5M', max: '2M'}
               ],
               'resale': [
                   {min: '100k', max: '200k'},
                   {min: '200k', max: '300k'},
                   {min: '300k', max: '400k'},
                   {min: '400k', max: '500k'}
               ],
               'rent': [
                   {min: '800', max: '1.2k'},
                   {min: '1.2k', max: '1.6k'},
                   {min: '1.6k', max: '2k'},
                   {min: '2k', max: '2.5k'}
               ]
           };
 
           // Clear current options
           minBudgetElement.innerHTML = '';
           maxBudgetElement.innerHTML = '';
 
           // Populate dropdowns based on selected offer type
           if (budgets[offerType]) {
               budgets[offerType].forEach(function(budget, index) {
                   let minOption = new Option(budget.min, budget.min);
                   let maxOption = new Option(budget.max, budget.max);
                   minBudgetElement.add(minOption);
                   maxBudgetElement.add(maxOption);
               });
           }
       }
 
       // Initialize on page load
       updateBudgetDropdowns();
 
       // Update dropdowns when offer type changes
       offerTypeElement.addEventListener('change', updateBudgetDropdowns);
   });
</script>
</head>
<body>
<?php include 'components/user_header.php'; ?>
 
<!-- home section starts -->
<div class="home">
<section class="center">
<form action="search.php" method="post">
<h3>find your perfect home</h3>
<div class="box">
<p>enter location <span>*</span></p>
<input type="text" name="h_location" required maxlength="100" placeholder="enter city name" class="input">
</div>
<div class="flex">
<div class="box">
<p>property type <span>*</span></p>
<select name="h_type" class="input" required>
<option value="flat">flat</option>
<option value="house">house</option>
<option value="shop">shop</option>
</select>
</div>
<div class="box">
<p>offer type <span>*</span></p>
<select id="h_offer" name="h_offer" class="input" required>
<option value="sale">sale</option>
<option value="resale">resale</option>
<option value="rent">rent</option>
</select>
</div>
<div class="box">
<p>minimum budget <span>*</span></p>
<select id="h_min" name="h_min" class="input" required>
<!-- Options added by JavaScript -->
</select>
</div>
<div class="box">
<p>maximum budget <span>*</span></p>
<select id="h_max" name="h_max" class="input" required>
<!-- Options added by JavaScript -->
</select>
</div>
</div>
<input type="submit" value="search property" name="h_search" class="btn">
</form>
</section>
</div>
<!-- home section ends -->
 
<!-- services section starts -->
<section class="services">
<h1 class="heading">our services</h1>
<div class="box-container">
<!-- Service boxes can be added here -->
</div>
</section>
<!-- services section ends -->
 
<!-- listings section starts -->
<section class="listings">
<h1 class="heading">latest listings</h1>
<div class="box-container">
<!-- Listing boxes can be added here -->
</div>
</section>
<!-- listings section ends -->
 
<?php include 'components/footer.php'; ?>
<?php include 'components/message.php'; ?>
</body>
</html>