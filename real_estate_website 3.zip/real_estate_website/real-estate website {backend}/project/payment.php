<?php
// Include the database connection
include 'components/connect.php';
 
// Check if user is logged in
if (isset($_COOKIE['user_id'])) {
    $user_id = $_COOKIE['user_id'];
} else {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit;
}
 
// Get the property ID and price from the query parameters
$property_id = isset($_GET['property_id']) ? $_GET['property_id'] : null;
$price = isset($_GET['price']) ? $_GET['price'] : null;
 
if (!$property_id || !$price) {
    // Handle missing property_id or price
    echo "Error: Missing property ID or price.";
    exit;
}
 
// Simulated payment process
// This is where you would typically handle payment processing
// using a payment gateway API, such as Stripe, PayPal, etc.
 
// For demonstration purposes, let's assume the payment is successful
 
// Log payment details in the database
$insert_payment = $conn->prepare("INSERT INTO payments (user_id, property_id, amount) VALUES (?, ?, ?)");
$insert_payment->execute([$user_id, $property_id, $price]);
 
// Display a success message
echo "<p>Payment of ₹{$price} for property ID {$property_id} was successful!</p>";
 
// Redirect user to a success page or back to the listings
// header('Location: success.php');
 
?>
 